OTF: Kingsmen (Thin, Regular, Bold, & Extra Bold)
Dennis Ludlow 2017 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Kingsmen is a classic styled slab serif loosely based on fonts found on posters of the 19th century. The geometric design is modeled closely around circles with no variation in stroke
width. Because of this it will make an attractive display font perfect for logos, slogans, and headlines. The serifs do change slightly to give Kingsmen a unique look. Basic Latin,
extended latin, numbers, punctuation, science/math symbols, European accents, diacritics, alternates, kerning, ligatures, and fractions are included in the complete version. Basic Latin, 
kerning, numbers, and very limited punctuation are included in the demo version. 

All 4 complete versions are available with purchase of commercial license or $25 payment via PayPal. Please note that this $25 is for PERSONAL use only and does not constitute a 
commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user
license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom fonts for companies, logos, and many other things. If you'd like to leave 
me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: display, font, typeface, publishing, logo, title, book, cover, Roman,  diacritics, French, Polish, Sharkshock, German, Portuguese, European, slab, serif, mono, weight, bold, thin,
line, classic, poster


